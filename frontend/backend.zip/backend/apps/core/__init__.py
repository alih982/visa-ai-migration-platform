"""Core package initialization"""
